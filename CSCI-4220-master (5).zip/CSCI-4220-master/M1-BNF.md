# Milestone 1

## BNF Grammar
```
Variable ::= Terminal | Terminal | Terminal 
```
### Assignment

### Declaration

### Block

### Conditional

### Iterator
```
FOR ::= for ITR { statement }
ITR ::= while conditional { statement } | while condiitional
```

### Pre/Post Increment/Decrement Statements
```
INCR ::= ++number | number++
DECR ::= --number | number--
```

### Print
```
PRT ::= ???
```